package com.org.test;

import static org.junit.Assert.assertEquals;

import java.util.Arrays;
import java.util.Collection;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

import com.org.NumberToWordConverter;
import com.org.processor.NumberToWordProcessor;

@RunWith(value = Parameterized.class)
public class NumberToWordConverterTest extends NumberToWordConverter {
	
	private final String expected;
    private final int input;

    public NumberToWordConverterTest(final String expected, final int input) {
        this.expected = expected;
        this.input = input;
    }

    @Parameters
    public static Collection<Object[]> data() {
        final Object[][] data = new Object[][] {
            { "One", 1},
            { "TwentyOne", 21},
            { "One HundredFive", 105},
            { "FiftySix Million Nine HundredFortyFive Thousand Seven HundredEightyOne", 56945781},
            { "Nine HundredNinetyNine Million Nine HundredNinetyNine Thousand Nine HundredNinetyNine", 999999999 }
         };
        return Arrays.asList(data);
    }

    @Test
    public void test() {
    	 assertEquals(expected, NumberToWordProcessor.numberToWord(input));
    }
}
