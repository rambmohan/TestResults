package com.org.processor;

import com.org.util.ConverterUtils;
import com.org.util.NumberRanges;

public class NumberToWordProcessor {
	
	public static String numberToWord(final int number){
		
		String wordForm = "";
		int quotient =0;
		int remainder = 0;
		int divisor = 0;
		if(number< NumberRanges.Ranges.ONE_BILLION.value && number>=NumberRanges.Ranges.ONE_MILLION.value)
		{
			divisor = NumberRanges.Ranges.ONE_MILLION.value;
			quotient = number/divisor;
			remainder = number % divisor;
			if(quotient!=0)
				wordForm += numberToWord(quotient) + " " + "Million";
			if(remainder!=0)
				wordForm+= " " + numberToWord(remainder);
		}
		else if(number<NumberRanges.Ranges.ONE_MILLION.value && number>=NumberRanges.Ranges.TEN_THOUSANDS.value){
			divisor = NumberRanges.Ranges.ONE_THOUSAND.value;
			quotient = number/divisor;
			remainder = number % divisor;
			if(quotient!=0)
				wordForm += numberToWord(quotient) + " " + "Thousand";
			if(remainder!=0)
				wordForm+= " " + numberToWord(remainder);
		}
		else if(number<NumberRanges.Ranges.TEN_THOUSANDS.value && number>=NumberRanges.Ranges.ONE_THOUSAND.value){
			divisor = NumberRanges.Ranges.ONE_THOUSAND.value;
			quotient = number/divisor;
			remainder = number % divisor;
			if(quotient!=0)
				wordForm += ConverterUtils.getNumberMap().get(quotient) + "Thousand";
			if(remainder!=0)
				wordForm+= numberToWord(remainder);

		}else if(number<NumberRanges.Ranges.ONE_THOUSAND.value && number>=NumberRanges.Ranges.ONE_HUNDRED.value){
			divisor = NumberRanges.Ranges.ONE_HUNDRED.value;
			quotient = number/divisor;
			remainder = number % divisor;
			if(quotient!=0)
				wordForm += ConverterUtils.getNumberMap().get(quotient) + " " + "Hundred";
			if(remainder!=0)
				wordForm +=numberToWord(remainder);

		}else if(number<NumberRanges.Ranges.ONE_HUNDRED.value && number>=NumberRanges.Ranges.TEN.value){
			divisor = NumberRanges.Ranges.TEN.value;
			quotient = number/divisor;
			remainder = number % divisor;
			if(quotient!=0)
				wordForm+= ConverterUtils.getNumberMap().get(quotient*divisor);
			if(remainder!=0)
				wordForm+= ConverterUtils.getNumberMap().get(remainder);
			
		}else if(number<NumberRanges.Ranges.TEN.value && number>=NumberRanges.Ranges.ZERO.value){
			wordForm +=  ConverterUtils.getNumberMap().get(number);
			
		}
		return wordForm;
	}
	
}
