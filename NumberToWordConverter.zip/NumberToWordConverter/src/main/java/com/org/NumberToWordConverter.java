package com.org;

import java.util.InputMismatchException;

import com.org.exceptions.ValidationException;
import com.org.processor.NumberToWordProcessor;

/**
 * 
 * @author Mohan
 *
 */
public class NumberToWordConverter {
	
	public static void main(String[] args){
		
		NumberToWordConverter numberToWordConverter = new NumberToWordConverter();
		numberToWordConverter.convert();
	}
	
	public void convert(){
		
		while(true){

			try{
				//Reading values from console
				int inputValue = NumberToWordInputReader.reader();

				//Validating inputs
				if(inputValue<0){				
					throw new ValidationException("Number can't be negative: " + inputValue);

				}else{
					// Process the input
					System.out.println(NumberToWordProcessor.numberToWord(inputValue));

				}
			}
			catch(ValidationException ve){
				System.out.println("input not validated - only accepts Integers values");
			}
			catch(NumberFormatException nfe){
				System.out.println("Only accepts Integer values");
				
			}catch(InputMismatchException ie){
				System.out.println("Only accepts Integer values");
				
			}
		}
	}
}
