package com.org;

import java.util.Scanner;

public class NumberToWordInputReader {
	
	public static int reader(){
		Scanner input = new Scanner(System.in);
		int value = input.nextInt();	
		return value;
	}

}
