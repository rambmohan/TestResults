package com.org.util;

public class NumberRanges {
	public static enum Ranges{

		ZERO(0), TEN(10), ONE_HUNDRED(100), ONE_THOUSAND(1000), TEN_THOUSANDS(10000), ONE_BILLION(1000000000),ONE_MILLION(1000000)   ;   

		public int value;  
		private Ranges(int value){  
			this.value=value;  
		}  
	}  
}
